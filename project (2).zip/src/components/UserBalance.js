import React from 'react';

const UserBalance = ({ balance }) => {
  return (
    <div className="bg-blue-900 rounded-lg p-4 shadow-md mb-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Tu Saldo</h2>
        <div className="flex items-center space-x-2">
          <span className="text-2xl font-bold text-yellow-400">{balance.toLocaleString()}</span>
          <span className="text-white">Diamantes</span>
        </div>
      </div>
    </div>
  );
};

export default UserBalance;