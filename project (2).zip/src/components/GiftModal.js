import React, { useState } from 'react';

const GiftModal = ({ product, onClose, onGift }) => {
  const [nickname, setNickname] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (nickname.trim()) {
      onGift(product, nickname);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-blue-900 rounded-xl p-6 max-w-md w-full">
        <h3 className="text-2xl font-bold text-white mb-4">Regalar {product.title}</h3>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-blue-200 mb-2">Nick del Jugador</label>
            <input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              className="w-full px-4 py-2 bg-blue-800 border border-blue-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ej: ProPlayer123"
              required
            />
          </div>
          <div className="flex space-x-3">
            <button
              type="submit"
              className="flex-1 bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded-lg transition-colors"
            >
              Confirmar Regalo
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-4 rounded-lg transition-colors"
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default GiftModal;