import React from 'react';

const NavigationBar = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'inicio', text: 'INICIO' },
    { id: 'login', text: 'LOGIN' },
    { id: 'kits', text: 'KITS' },
    { id: 'llaves', text: 'LLAVES' },
    { id: 'rangos', text: 'RANGOS' },
    { id: 'exclusivos', text: 'OBJETOS EXCLUSIVOS' }
  ];

  return (
    <div className="bg-blue-800 py-3 shadow-md">
      <div className="container mx-auto px-4">
        <nav className="flex overflow-x-auto space-x-6">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`whitespace-nowrap px-3 py-1 font-medium transition-colors border-b-2 ${
                activeTab === tab.id 
                  ? 'text-yellow-300 border-yellow-300' 
                  : 'text-white hover:text-yellow-200 border-transparent'
              }`}
            >
              {tab.text}
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default NavigationBar;