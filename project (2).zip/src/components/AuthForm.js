import React, { useState } from 'react';

const AuthForm = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin(username);
  };

  return (
    <div className="max-w-md mx-auto bg-blue-900 rounded-xl shadow-md overflow-hidden p-8 mt-16">
      <div className="text-center mb-8">
        <img 
          src="https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc073LIZd9ulj9cdOX5xw8FV0A6Wpo2KaRHmChz" 
          alt="MINEFLOD Logo" 
          className="h-24 w-24 mx-auto rounded-full border-4 border-blue-700"
        />
        <h2 className="text-3xl font-bold text-white mt-4">MINEFLOD</h2>
        <p className="text-blue-300">Box PvP Server</p>
      </div>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-blue-200 mb-2">Usuario</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full px-4 py-2 bg-blue-800 border border-blue-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        <div className="mb-6">
          <label className="block text-blue-200 mb-2">Contraseña</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-2 bg-blue-800 border border-blue-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-4 rounded-lg transition-colors"
        >
          Ingresar
        </button>
      </form>
    </div>
  );
};

export default AuthForm;