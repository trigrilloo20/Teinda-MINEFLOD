import React from 'react';
import SearchBar from './SearchBar';
import NavigationBar from './NavigationBar';
import StoreHeader from './StoreHeader';
import UserBalance from './UserBalance';
import StoreGrid from './StoreGrid';
import StoreFooter from './StoreFooter';

const AppLayout = ({ user, searchQuery, onSearch, activeTab, setActiveTab }) => {
  return (
    <>
      <SearchBar onSearch={onSearch} />
      <NavigationBar activeTab={activeTab} setActiveTab={setActiveTab} />
      <StoreHeader username={user?.name} />
      <main className="container mx-auto px-4 py-8">
        {user && <UserBalance balance={user.balance} />}
        <StoreGrid 
          searchQuery={searchQuery} 
          activeTab={activeTab}
        />
      </main>
      <StoreFooter />
    </>
  );
};

export default AppLayout;