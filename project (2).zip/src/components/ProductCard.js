import React, { useState } from 'react';
import GiftModal from './GiftModal';

const ProductCard = ({ title, price, image, description, specs, onGift }) => {
  const [showSpecs, setShowSpecs] = useState(false);
  const [showGiftModal, setShowGiftModal] = useState(false);

  return (
    <div className="bg-blue-800 rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
      <div className="h-48 bg-blue-900 flex items-center justify-center">
        <img src={image} alt={title} className="h-full object-cover" />
      </div>
      <div className="p-4">
        <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
        <p className="text-blue-200 mb-4">{description}</p>
        
        {showSpecs && (
          <div className="mt-3 p-3 bg-blue-900 rounded-lg mb-4">
            <h4 className="font-bold text-white mb-2">Especificaciones:</h4>
            <ul className="text-blue-200 list-disc pl-5">
              {specs.map((spec, i) => (
                <li key={i}>{spec}</li>
              ))}
            </ul>
          </div>
        )}

        <div className="flex items-center justify-between mb-3">
          <span className="text-2xl font-bold text-yellow-400">{price} Diamantes</span>
          <button 
            className="bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded-lg transition-colors"
            onClick={() => setShowGiftModal(true)}
          >
            Regalar
          </button>
        </div>

        <div className="flex space-x-2">
          <button 
            onClick={() => setShowSpecs(!showSpecs)}
            className="flex-1 bg-blue-700 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors"
          >
            {showSpecs ? 'Ocultar' : 'Ver'} Especificaciones
          </button>
          <button 
            className="flex-1 bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-lg transition-colors"
          >
            Comprar
          </button>
        </div>
      </div>

      {showGiftModal && (
        <GiftModal
          product={{ title, price }}
          onClose={() => setShowGiftModal(false)}
          onGift={onGift}
        />
      )}
    </div>
  );
};

export default ProductCard;