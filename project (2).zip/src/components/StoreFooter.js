import React from 'react';

const StoreFooter = () => {
  return (
    <footer className="bg-blue-900 py-6 px-4 mt-8">
      <div className="container mx-auto">
        <div className="text-center text-red-400 mb-4">
          <p>⚠️ MORGAN no autoriza ni respalda esta página. Uso bajo tu propio riesgo.</p>
          <p>Esta tienda no está afiliada oficialmente con el servidor MINEFLOD.</p>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-xl font-bold text-white">MINEFLOD</h2>
            <p className="text-blue-300">Box PvP Server</p>
          </div>
          <div className="flex space-x-4">
            <a href="#" className="text-blue-300 hover:text-white transition-colors">
              Términos
            </a>
            <a href="#" className="text-blue-300 hover:text-white transition-colors">
              Políticas
            </a>
          </div>
        </div>
        <div className="mt-6 text-center text-blue-400">
          <p>© 2023 MINEFLOD. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default StoreFooter;