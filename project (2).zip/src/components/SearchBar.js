import React, { useState } from 'react';

const SearchBar = ({ onSearch }) => {
  const [query, setQuery] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    onSearch(query);
  };

  return (
    <div className="bg-blue-900 py-4 px-6 shadow-md">
      <div className="container mx-auto">
        <form onSubmit={handleSearch} className="flex">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar kits, armas, items..."
            className="flex-grow px-4 py-2 bg-blue-800 text-white rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-500 px-4 py-2 text-white rounded-r-lg transition-colors"
          >
            Buscar
          </button>
        </form>
      </div>
    </div>
  );
};

export default SearchBar;