import React from 'react';

const StoreHeader = ({ username }) => {
  return (
    <header className="bg-blue-900 py-6 px-4 shadow-lg">
      <div className="container mx-auto flex flex-col items-center">
        <img 
          src="https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc073LIZd9ulj9cdOX5xw8FV0A6Wpo2KaRHmChz" 
          alt="MINEFLOD Logo" 
          className="h-20 w-20 rounded-full border-2 border-blue-700 mb-4"
        />
        <h1 className="text-4xl font-bold text-white mb-2">MINEFLOD</h1>
        {username && (
          <div className="bg-blue-800 px-4 py-1 rounded-full">
            <span className="text-white">Bienvenido, {username}</span>
          </div>
        )}
      </div>
    </header>
  );
};

export default StoreHeader;