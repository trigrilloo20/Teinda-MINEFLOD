import React, { useState } from 'react';
import ProductCard from './ProductCard';

const StoreGrid = ({ searchQuery, activeTab }) => {
  const [giftMessage, setGiftMessage] = useState(null);

  const allProducts = {
    rangos: [
      {
        id: 1,
        title: 'Rango VIP',
        price: 5000,
        image: 'https://i.imgur.com/JQJxQ0a.png',
        description: 'Acceso a beneficios básicos VIP',
        specs: [
          'Tag VIP en el juego',
          'Acceso a /fly',
          '1 Kit VIP semanal',
          'Color en el chat'
        ]
      },
      {
        id: 2,
        title: 'Rango VIP+',
        price: 8000,
        image: 'https://i.imgur.com/9QJxQ0b.png',
        description: 'Beneficios VIP mejorados',
        specs: [
          'Todos los beneficios VIP',
          '2 Kits VIP+ semanales',
          'Acceso a /hat',
          'Particulas especiales'
        ]
      }
    ]
  };

  const handleGift = (product, nickname) => {
    setGiftMessage(`¡Has regalado ${product.title} a ${nickname} por ${product.price} diamantes!`);
    setTimeout(() => setGiftMessage(null), 5000);
  };

  const products = allProducts[activeTab] || [];
  
  const filteredProducts = products.filter(product =>
    product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container mx-auto px-4 py-8">
      {giftMessage && (
        <div className="bg-green-600 text-white p-4 rounded-lg mb-6 text-center">
          {giftMessage}
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredProducts.map(product => (
          <ProductCard
            key={product.id}
            title={product.title}
            price={product.price}
            image={product.image}
            description={product.description}
            specs={product.specs}
            onGift={handleGift}
          />
        ))}
      </div>
    </div>
  );
};

export default StoreGrid;

// DONE