import React, { useState } from 'react';
import AuthForm from './components/AuthForm';
import AppLayout from './components/AppLayout';

const App = () => {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('rangos');

  const handleLogin = (username) => {
    setUser({
      name: username,
      balance: 15000
    });
    setActiveTab('rangos');
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
  };

  return (
    <div className="min-h-screen bg-blue-950 text-white">
      {!user ? (
        <AuthForm onLogin={handleLogin} />
      ) : (
        <AppLayout 
          user={user} 
          searchQuery={searchQuery} 
          onSearch={handleSearch}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />
      )}
    </div>
  );
};

export default App;